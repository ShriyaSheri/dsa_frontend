import React from "react";

function Sample(props) {
  const { question } = props;
  return (
    <div>
      <div>${question.Problem}</div>
      <a href={question.URL} target="_blank"
            rel="noopener noreferrer" >Link</a>
    </div>
  );
}

export default Sample;
