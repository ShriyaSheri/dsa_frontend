import React from 'react'

function Header() {
  return (
    <div>
      DSA-Tracker
    </div>
  )
}

export default Header
