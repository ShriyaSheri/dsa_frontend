import React from "react";
import { Link } from "react-router-dom";
function Card(props) {
    const {changeCategory,title,doneQuestions,categoryData}=props
  return (
    <div className="note">
      <h1>{title}</h1>
      <p>{doneQuestions}</p>
      <Link to={`/${title}`} class="button" onClick={()=>changeCategory(categoryData)}>Start</Link>
    </div>
  );
}

export default Card;
