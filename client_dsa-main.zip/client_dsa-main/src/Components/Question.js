import React from "react";
import Sample from "./Sample";

function Question(props) {
  const { category } = props;
  const questions = category.questions;

  return (
    <div>
      {questions.map((element) => (
        <div key={element.URL}>
          <Sample question={element} />
        </div>
      ))}
    </div>
  );
}

export default Question;
